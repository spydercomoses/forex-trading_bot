from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from keras.models import load_model
import os
import pandas as pd
from utils.data_preprocessing import preprocess_data
from utils.chat_analysis import analyze_chat
from utils.model_training import train_model

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Load the pre-trained model
MODEL_PATH = 'models/forex_model.h5'
model = None
if os.path.exists(MODEL_PATH):
    try:
        model = load_model(MODEL_PATH)
        print("Model loaded successfully.")
    except Exception as e:
        print(f"Error loading model: {e}")
else:
    print("Model not found. Please train the model first.")

@app.route('/')
def home():
    """Renders the home dashboard."""
    return render_template('dashboard.html', prediction=None, sentiment=None)

@app.route('/predict', methods=['POST'])
def predict():
    """Handles Forex trend prediction."""
    if model is None:
        flash("Model not loaded. Please train the model first.", "danger")
        return redirect(url_for('home'))

    try:
        input_data = request.form.get('input_data')
        if not input_data:
            flash("No input data provided for prediction.", "warning")
            return redirect(url_for('home'))

        processed_data = preprocess_data(input_data)  # Assuming this preprocesses user input
        prediction = model.predict(processed_data)
        prediction = prediction.flatten()[0]  # Get the scalar value
        flash(f"Prediction successful: {prediction:.2f}", "success")
    except Exception as e:
        flash(f"Error during prediction: {str(e)}", "danger")
        return redirect(url_for('home'))

    return render_template('dashboard.html', prediction=prediction)

@app.route('/analyze_chat', methods=['POST'])
def analyze_chat_data():
    """Analyzes chat sentiment."""
    try:
        chat_data = request.form.get('chat_data')
        if not chat_data:
            flash("No chat data provided for analysis.", "warning")
            return redirect(url_for('home'))

        sentiment_analysis = analyze_chat(chat_data)  # Sentiment analysis utility
        flash("Chat analysis completed successfully.", "success")
    except Exception as e:
        flash(f"Error analyzing chat: {str(e)}", "danger")
        return redirect(url_for('home'))

    return render_template('dashboard.html', sentiment=sentiment_analysis)

@app.route('/train', methods=['POST'])
def train():
    """Triggers model training."""
    try:
        train_model('data/sample_forex_data.csv')  # Assuming it trains the model and saves it
        flash("Model training completed successfully!", "success")
    except Exception as e:
        flash(f"Error during model training: {str(e)}", "danger")
        return redirect(url_for('home'))

    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
