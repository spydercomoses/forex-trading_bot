import pytest
from app import app

@pytest.fixture
def client():
    with app.test_client() as client:
        yield client

def test_home(client):
    response = client.get('/')
    assert response.status_code == 200

def test_predict(client):
    response = client.post('/predict', json={'data': [1.115]})
    assert response.status_code == 200
    assert 'prediction' in response.get_json()
