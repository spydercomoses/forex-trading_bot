import pandas as pd
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam
from sklearn.preprocessing import MinMaxScaler
import numpy as np

# Load Forex data
data = pd.read_csv('data/sample_forex_data.csv')

# Preprocess the data (simple example)
data = data[['Open', 'High', 'Low', 'Close']]  # Use Open, High, Low, Close prices

# Normalize the features
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(data)

# Define the features (X) and target (y)
X = scaled_data[:-1]  # All rows except the last one
y = scaled_data[1:, 3]  # Use the Close price of the next day as the target (Close)

# Ensure the dataset has enough samples for splitting
if len(X) > 1:
    # Split data into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
else:
    print("Not enough data points to split, using the entire dataset for training.")
    # Use the entire dataset for training
    X_train, y_train = X, y
    X_test, y_test = X, y  # In this case, the model will be evaluated on the same data

# Build a simple neural network model
model = Sequential()
model.add(Dense(64, activation='relu', input_dim=X_train.shape[1]))  # Input layer
model.add(Dense(32, activation='relu'))  # Hidden layer
model.add(Dense(1))  # Output layer (predicting Close price)

# Compile the model
model.compile(optimizer=Adam(), loss='mean_squared_error')

# Train the model
model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test))

# Save the model
model.save('models/forex_model.h5')
print("Model saved as models/forex_model.h5")
