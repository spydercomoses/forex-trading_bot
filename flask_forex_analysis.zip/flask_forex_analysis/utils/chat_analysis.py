from nltk.sentiment import SentimentIntensityAnalyzer

def analyze_chat(chat_text):
    sia = SentimentIntensityAnalyzer()
    return sia.polarity_scores(chat_text)

